import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Product2 p2 = new Product2();
        int a;
        p2.welcome();
        int x= sc.nextInt();


        do {
            if(x==1){
                System.out.println("What You Want To Buy?");
                System.out.println("1.APPLE");
                System.out.println("2.BANANA");
                System.out.println("3.WATERMELON");
                System.out.println("4.MANGO.");
                System.out.println("5.ORANGE");
                int n = sc.nextInt();
                if (n == 1) {
                    System.out.println("Per Pcs Apple Price=20Tk");
                    System.out.println("Enter Quantity Of APPLE=");
                    p2.apple();
                    p2.total();
                } else if (n == 2) {
                    System.out.println("Per Pcs BANANA Price=8Tk");
                    System.out.println("Enter Quantity Of BANANA=");
                    p2.banana();
                    p2.total();
                } else if (n == 3) {
                    System.out.println("Per Pcs WATERMELON Price=80Tk");
                    System.out.println("Enter Quantity Of WATERMELON=");
                    p2.watermelon();
                    p2.total();
                } else if (n == 4) {
                    System.out.println("Per Pcs MANGO Price=10Tk");
                    System.out.println("Enter Quantity Of MANGO=");
                    p2.mango();
                    p2.total();
                } else if (n == 5) {
                    System.out.println("Per Pcs ORANGE Price=18Tk");
                    System.out.println("Enter Quantity Of ORANGE=");
                    p2.orange();
                    p2.total();
                }
                else {
                    System.out.println("Invalid Number");
                }//Product else
            }
            else{
                System.out.println("Invalid");
                break;
            }//Press 1 Else
            System.out.println("Enter '1' to Continue Buying Fruits ");
            System.out.println("Enter Any Other Number To Exit");
            a = sc.nextInt();


        } while (a == 1);
        System.out.println("Thank you for your purchase");
        p2.total();
    }
}