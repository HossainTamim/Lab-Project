import java.util.Scanner;
public class Product2 implements Product {
    int total;
    Scanner sc = new Scanner(System.in);
    public void total() {
        System.out.println("Total Purchased = " + total);
    }

    public void apple() {
        int apple_price = 20;
        int quantity = sc.nextInt();
        total = total + (apple_price* quantity);
    }

    public void banana() {
        int Banana = 8;
        int quantity = sc.nextInt();
        total = total + (Banana* quantity);
    }



    public void watermelon() {
        int watermelon=80;
        int quantity = sc.nextInt();
        total = total + (watermelon * quantity);
    }

    public void mango() {
        int mango = 10;
        int quantity = sc.nextInt();
        total = total + (mango* quantity);
    }

    public void orange() {
        int orange = 18;
        int quantity = sc.nextInt();
        total = total + (orange* quantity);
    }
    public void welcome() {
        System.out.println("                   Welcome   User                ");
        System.out.println("                  PRESS 1 TO START               ");

    }

}