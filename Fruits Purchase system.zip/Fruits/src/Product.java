public interface Product {
    public void apple();
    public void banana();

    public  void watermelon();
    public  void mango();
    public  void orange();

}